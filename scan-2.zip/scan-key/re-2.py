
import re
import os
import linecache



def do_parse(one_line_str):
    #...if can not parse, return None
    if '-----BEGIN' not in one_line_str:
        return None
    substr = ":"
    pos = [each.start() for each in re.finditer(substr, one_line_str)]
    print(pos)
    file = one_line_str[0 : pos[0]]
    line = int(one_line_str[pos[0] + 1 : pos[1]])
    print(file, ':', line)
    
    return (file, line)

def get_key(file_path, line_number):
    begin = linecache.getline(file_path, line_number).strip()
    if(not begin.startswith('-----BEGIN')):
        print('file:{} line:{} not right format'.format(file_path, line_number))
        return ''
    
    key_str = ''
    line_number += 1
    next_line = linecache.getline(file_path, line_number).strip()
    while(not next_line.startswith('-----END')):
        next_line += ' '
        key_str += next_line
        line_number += 1
        next_line = linecache.getline(file_path, line_number).strip()
    # print(key_str)
    key_str = key_str[0:len(key_str) - 1]
    # print(key_str[-1])
    # print(key_str[0])

    return key_str



files = [x for x in os.listdir('.') if os.path.isfile(x) and os.path.splitext(x)[1]=='.txt']
file_line_list = []#tuple list
files_result_dict = {}
files_result_set = set()
files_result_list = []
for file in files:
    print('check file: ', file)
    with open(file, 'r') as f:
        each_file_result_set = set()
        for line in f.readlines():
            ret = do_parse(line)
            if ret is not None:
                tmp_key = get_key(ret[0], ret[1])
                each_file_result_set.add(tmp_key)
                files_result_set.add(tmp_key)
        files_result_dict[os.path.splitext(file)[0]] = list(each_file_result_set)

files_result_list = list(files_result_set)
with open('./ana.ana', 'w') as f:
    for item in files_result_list:
        f.write(item + '\n')
    f.write('\n\n\n\n\n')
    s = 'total is: ' + str(len(files_result_list))
    f.write(s)
    f.write('\n\n\n\n\n')
    f.write('details:\n')
    for key in files_result_dict.keys():
        if len(files_result_dict[key]) > 0:
            f.write(key + '\n')
    f.write('\n\n\n')
    for value in files_result_dict.values():
        if len(value) > 0:
            s = str(len(value)) + '\n'
            f.write(s)


with open('./ana2.ana', 'w') as f:
    for key, value in files_result_dict.items():
        if len(files_result_dict[key]) > 0:
            f.write(key + ':\n')
            for v in files_result_dict[key]:
                f.write(v + '\n')
            f.write('\n')