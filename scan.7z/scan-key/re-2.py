
import re
import os
import linecache



# def do_parse(one_line_str):
#     #...if can not parse, return None
#     return (file, line)

def get_key(file_path, line_number):
    begin = linecache.getline(file_path, line_number).strip()
    if(not begin.startswith('-----BEGIN')):
        print('file:{} line:{} not right format'.format(file_path, line_number))
        return ''
    
    key_str = ''
    line_number += 1
    next_line = linecache.getline(file_path, line_number).strip()
    while(not next_line.startswith('-----END')):
        next_line += ' '
        key_str += next_line
        line_number += 1
        next_line = linecache.getline(file_path, line_number).strip()
    # print(key_str)
    key_str = key_str[0:len(key_str) - 1]
    # print(key_str[-1])
    # print(key_str[0])

    return key_str



# files = [x for x in os.listdir('.') if os.path.isfile(x) and os.path.splitext(x)[1]=='.txt']
# file_line_list = []#tuple list
# for item in files:
#     print('check file: ', item)
#     with open(item, 'r') as f:
#         for line in f.readlines():
#             ret = do_parse(line)
#             if ret is not None:
#                 file_line_list.append(ret)


keys = []
# keys.append(get_key('./scan.txt', 3))
# keys.append(get_key('./scan.txt', 21))
# keys.append(get_key('./scan.txt', 41))
file_line_list = [('./scan.txt', 3), ('./scan.txt', 21), ('./scan.txt', 41)]
for item in file_line_list:
    keys.append(get_key(item[0], item[1]))

keys_set = set(keys)
print('keys_set len:', len(keys_set))
for i in keys_set:
    print(i)

