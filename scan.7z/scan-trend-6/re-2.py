
import re
import os

# pattern = re.compile(r'\d+')   # find numbers
# result1 = pattern.findall('runoob 123 google 456')
# result2 = pattern.findall('run88oob123google456', 0, 10)
 

pattern = re.compile(r'trend[a-zA-Z]*[/\\]+.*')
#pattern = re.compile(r'[0-9a-zA-Z]+-[0-9a-zA-Z]+@[a-zA-Z]{2}.trendnet.org')
files = [x for x in os.listdir('.') if os.path.isfile(x) and os.path.splitext(x)[1]=='.txt']
result = []
for item in files:
    print('check file: ', item)
    with open(item, 'r') as f:
        tmp = pattern.findall(f.read())
        for i in tmp:
            result.append(i)

ret_set = set(result)
for item in ret_set:
    print(item)

# with open('./ana2.ana', 'w') as f:
#     for item in ret_set:
#         f.write(item + '\n')




#result2 = pattern.findall('id = qwefvn67-qazw-g5u7-1234567890ab')
#print(result2)

